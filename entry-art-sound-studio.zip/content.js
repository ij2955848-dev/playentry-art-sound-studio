(() => {
  const LAUNCHER_ID = "entry-studio-launcher";
  const PANEL_ID = "entry-studio-panel";

  if (document.getElementById(LAUNCHER_ID) || document.getElementById(PANEL_ID)) {
    return;
  }

  // --- 색상 유틸리티 함수 ---
  function clamp(val, min, max) {
    return Math.min(max, Math.max(min, val));
  }

  function hexToRgb(hex) {
    const clean = hex.replace("#", "").trim();
    if (clean.length !== 6) return { r: 37, g: 99, b: 235 };
    const num = parseInt(clean, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255
    };
  }

  function rgbToHex(r, g, b) {
    const toHex = (n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0");
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return { h: h * 360, s: s * 100, l: l * 100 };
  }

  function hslToHex(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = clamp(s, 0, 100) / 100;
    l = clamp(l, 0, 100) / 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return rgbToHex((r + m) * 255, (g + m) * 255, (b + m) * 255);
  }

  function initStudio() {
    if (!document.body) return;

    const launcher = document.createElement("button");
    launcher.id = LAUNCHER_ID;
    launcher.type = "button";
    launcher.innerHTML = "🎨 아트·사운드 스튜디오";

    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="es-header">
        <span class="es-title">🎨 엔트리 아트 & 사운드 스튜디오</span>
        <button type="button" class="es-close" id="es-close-btn" title="닫기">✕</button>
      </div>

      <div class="es-tabs">
        <button type="button" class="es-tab active" data-tab="color">스포이드·팔레트</button>
        <button type="button" class="es-tab" data-tab="size">480×270 계산기</button>
        <button type="button" class="es-tab" data-tab="sound">BGM·박자 계산</button>
      </div>

      <div class="es-body">
        <!-- 1. 컬러 스포이드 & 조화 팔레트 -->
        <div class="es-section active" id="es-sec-color">
          <span class="es-label">화면 색상 추출 (스포이드)</span>
          <div class="es-row">
            <button type="button" class="es-btn primary" id="es-eyedropper-btn">💧 화면에서 색 찍기</button>
            <input type="color" class="es-color-picker" id="es-color-input" value="#2563EB" title="직접 색상 선택">
          </div>

          <div class="es-color-card">
            <div class="es-swatch-main" id="es-main-swatch" style="background:#2563EB;"></div>
            <div class="es-color-codes">
              <div style="margin-bottom:4px;">
                <span class="es-code-copy" id="es-hex-code" title="클릭해 복사">#2563EB</span>
                <span class="es-code-copy" id="es-rgb-code" title="클릭해 복사">37, 99, 235</span>
              </div>
              <div style="font-size:11px;color:#64748b;">코드를 클릭하면 클립보드에 복사됩니다</div>
            </div>
          </div>

          <span class="es-label">추천 조화 팔레트 (클릭 시 HEX 복사)</span>
          <div class="es-palette-grid" id="es-palette-grid"></div>
        </div>

        <!-- 2. 480x270 스프라이트 크기 & 충돌 계산기 -->
        <div class="es-section" id="es-sec-size">
          <span class="es-label">화면 비율 기준 스프라이트 픽셀 계산 (480 × 270)</span>
          <div class="es-row">
            <div style="flex:1;">
              <span style="font-size:11px;color:#64748b;">가로 분할 (1 / N)</span>
              <input type="number" class="es-input" id="es-div-x" value="5" min="1" max="100" step="0.5">
            </div>
            <div style="flex:1;">
              <span style="font-size:11px;color:#64748b;">세로 분할 (1 / N)</span>
              <input type="number" class="es-input" id="es-div-y" value="4" min="1" max="100" step="0.5">
            </div>
          </div>

          <div class="es-result-box" id="es-size-result"></div>

          <div style="margin-top:12px;">
            <span class="es-label">모양 크기(%) → 실제 좌표 크기 & 충돌 반경</span>
            <div class="es-row">
              <input type="number" class="es-input" id="es-shape-px" value="64" min="1" max="1000" placeholder="원본 픽셀(px)">
              <input type="number" class="es-input" id="es-shape-scale" value="100" min="1" max="500" placeholder="크기(%)">
            </div>
            <div class="es-result-box" id="es-hitbox-result"></div>
          </div>
        </div>

        <!-- 3. BGM BPM -> 엔트리 초(sec) 변환기 -->
        <div class="es-section" id="es-sec-sound">
          <span class="es-label">리듬·액션 타이밍 BPM → 기다리기(초) 계산기</span>
          <div class="es-row">
            <input type="number" class="es-input" id="es-bpm-input" value="120" min="20" max="400" placeholder="BPM 입력 (예: 120)">
            <button type="button" class="es-btn" id="es-tap-btn">🥁 박자 탭</button>
          </div>
          <div class="es-result-box" id="es-bpm-result"></div>
        </div>

        <div class="es-toast" id="es-toast"></div>
      </div>
    `;

    document.body.appendChild(launcher);
    document.body.appendChild(panel);

    const toastEl = panel.querySelector("#es-toast");
    let toastTimer = null;
    function showToast(msg, isError = false) {
      toastEl.style.color = isError ? "#dc2626" : "#059669";
      toastEl.textContent = msg;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        toastEl.textContent = "";
      }, 2400);
    }

    function copyText(text) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(`복사됨: ${text}`);
      }).catch(() => {
        showToast(`값: ${text}`);
      });
    }

    // 열기/닫기
    launcher.addEventListener("click", () => {
      panel.classList.toggle("is-open");
    });
    panel.querySelector("#es-close-btn").addEventListener("click", () => {
      panel.classList.remove("is-open");
    });

    // 탭 전환
    const tabs = panel.querySelectorAll(".es-tab");
    const sections = panel.querySelectorAll(".es-section");
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.remove("active"));
        sections.forEach((s) => s.classList.remove("active"));
        tab.classList.add("active");
        panel.querySelector(`#es-sec-${tab.dataset.tab}`).classList.add("active");
      });
    });

    // --- 1. 컬러 로직 ---
    const colorInput = panel.querySelector("#es-color-input");
    const mainSwatch = panel.querySelector("#es-main-swatch");
    const hexCodeEl = panel.querySelector("#es-hex-code");
    const rgbCodeEl = panel.querySelector("#es-rgb-code");
    const paletteGrid = panel.querySelector("#es-palette-grid");

    function updateColorUI(hex) {
      const normalized = hex.toUpperCase();
      const { r, g, b } = hexToRgb(normalized);
      const { h, s, l } = rgbToHsl(r, g, b);

      colorInput.value = normalized;
      mainSwatch.style.background = normalized;
      hexCodeEl.textContent = normalized;
      rgbCodeEl.textContent = `${r}, ${g}, ${b}`;

      const harmonies = [
        { label: "밝은 톤", hex: hslToHex(h, Math.max(15, s - 8), Math.min(92, l + 18)) },
        { label: "어두운 톤", hex: hslToHex(h, Math.min(100, s + 6), Math.max(12, l - 20)) },
        { label: "보색(강조)", hex: hslToHex(h + 180, s, l) },
        { label: "유사색", hex: hslToHex(h + 32, s, l) }
      ];

      paletteGrid.innerHTML = harmonies.map((item) => `
        <div class="es-palette-item" data-hex="${item.hex}" title="${item.label}: ${item.hex} (클릭해 복사)">
          <div class="es-palette-color" style="background:${item.hex};"></div>
          <span class="es-palette-tag">${item.label}</span>
        </div>
      `).join("");

      paletteGrid.querySelectorAll(".es-palette-item").forEach((el) => {
        el.addEventListener("click", () => copyText(el.dataset.hex));
      });
    }

    colorInput.addEventListener("input", (e) => updateColorUI(e.target.value));
    hexCodeEl.addEventListener("click", () => copyText(hexCodeEl.textContent));
    rgbCodeEl.addEventListener("click", () => copyText(rgbCodeEl.textContent));

    panel.querySelector("#es-eyedropper-btn").addEventListener("click", async () => {
      if (!("EyeDropper" in window)) {
        showToast("이 브라우저는 스포이드 API를 지원하지 않아 색상창을 사용하세요.", true);
        colorInput.click();
        return;
      }
      try {
        const eyeDropper = new EyeDropper();
        const result = await eyeDropper.open();
        updateColorUI(result.sRGBHex);
        copyText(result.sRGBHex.toUpperCase());
      } catch (err) {
        // 사용자가 ESC로 취소한 경우 조용히 무시
      }
    });

    updateColorUI("#2563EB");

    // --- 2. 480x270 좌표/크기 계산 로직 ---
    const divXInput = panel.querySelector("#es-div-x");
    const divYInput = panel.querySelector("#es-div-y");
    const sizeResultEl = panel.querySelector("#es-size-result");
    const shapePxInput = panel.querySelector("#es-shape-px");
    const shapeScaleInput = panel.querySelector("#es-shape-scale");
    const hitboxResultEl = panel.querySelector("#es-hitbox-result");

    function updateSizeCalc() {
      const dx = Math.max(0.1, parseFloat(divXInput.value) || 1);
      const dy = Math.max(0.1, parseFloat(divYInput.value) || 1);
      const w = +(480 / dx).toFixed(1);
      const h = +(270 / dy).toFixed(1);
      const colRadius = +(Math.min(w, h) * 0.4).toFixed(1);

      sizeResultEl.innerHTML = `
        <div class="es-result-row">
          <span>권장 그리기 크기</span>
          <span class="es-result-val">${w} × ${h} px</span>
        </div>
        <div class="es-result-row">
          <span>자연스러운 충돌 반경</span>
          <span class="es-result-val">약 ${colRadius} (지름 ${(colRadius * 2).toFixed(1)})</span>
        </div>
      `;

      const origPx = Math.max(1, parseFloat(shapePxInput.value) || 1);
      const scalePct = Math.max(1, parseFloat(shapeScaleInput.value) || 100);
      const realSize = +(origPx * (scalePct / 100)).toFixed(1);
      const ratioPct = +((realSize / 480) * 100).toFixed(1);

      hitboxResultEl.innerHTML = `
        <div class="es-result-row">
          <span>실제 화면 점유 크기</span>
          <span class="es-result-val">${realSize} px (가로 대비 ${ratioPct}%)</span>
        </div>
        <div class="es-result-row">
          <span>중심 기준 X/Y 여유 거리</span>
          <span class="es-result-val">±${(realSize / 2).toFixed(1)}</span>
        </div>
      `;
    }

    [divXInput, divYInput, shapePxInput, shapeScaleInput].forEach((inp) => {
      inp.addEventListener("input", updateSizeCalc);
    });
    updateSizeCalc();

    // --- 3. BPM 박자 변환 & 탭 템포 ---
    const bpmInput = panel.querySelector("#es-bpm-input");
    const bpmResultEl = panel.querySelector("#es-bpm-result");
    const tapBtn = panel.querySelector("#es-tap-btn");
    let tapTimes = [];

    function updateBpmCalc() {
      const bpm = Math.max(1, parseFloat(bpmInput.value) || 120);
      const beat1 = 60 / bpm;
      const beatHalf = beat1 / 2;
      const beatQuarter = beat1 / 4;
      const bar4 = beat1 * 4;

      bpmResultEl.innerHTML = `
        <div class="es-result-row">
          <span>1박자 (4분음표)</span>
          <span class="es-result-val" style="cursor:pointer;" data-sec="${beat1.toFixed(3)}">${beat1.toFixed(3)} 초</span>
        </div>
        <div class="es-result-row">
          <span>반박자 (8분음표)</span>
          <span class="es-result-val" style="cursor:pointer;" data-sec="${beatHalf.toFixed(3)}">${beatHalf.toFixed(3)} 초</span>
        </div>
        <div class="es-result-row">
          <span>1/4박자 (16분음표)</span>
          <span class="es-result-val" style="cursor:pointer;" data-sec="${beatQuarter.toFixed(3)}">${beatQuarter.toFixed(3)} 초</span>
        </div>
        <div class="es-result-row">
          <span>1마디 (4/4박자)</span>
          <span class="es-result-val" style="cursor:pointer;" data-sec="${bar4.toFixed(3)}">${bar4.toFixed(3)} 초</span>
        </div>
      `;

      bpmResultEl.querySelectorAll("[data-sec]").forEach((el) => {
        el.title = "클릭해 초 값 복사";
        el.addEventListener("click", () => copyText(el.dataset.sec));
      });
    }

    bpmInput.addEventListener("input", updateBpmCalc);
    tapBtn.addEventListener("click", () => {
      const now = performance.now();
      if (tapTimes.length > 0 && now - tapTimes[tapTimes.length - 1] > 2000) {
        tapTimes = [];
      }
      tapTimes.push(now);
      if (tapTimes.length > 6) tapTimes.shift();
      if (tapTimes.length >= 2) {
        const diffs = [];
        for (let i = 1; i < tapTimes.length; i++) {
          diffs.push(tapTimes[i] - tapTimes[i - 1]);
        }
        const avgMs = diffs.reduce((a, b) => a + b, 0) / diffs.length;
        const estBpm = Math.round(60000 / avgMs);
        bpmInput.value = estBpm;
        updateBpmCalc();
        showToast(`탭 측정 BPM: ${estBpm}`);
      } else {
        showToast("박자에 맞춰 버튼을 연속으로 눌러보세요!");
      }
    });

    updateBpmCalc();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initStudio, { once: true });
  } else {
    initStudio();
  }
})();
